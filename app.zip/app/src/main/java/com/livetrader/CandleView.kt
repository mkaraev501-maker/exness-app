package com.livetrader

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.view.View

class Candle(val o: Double, val h: Double, val l: Double, val c: Double)

/** Японские свечи, как в Pocket Option: зелёная растёт, красная падает. */
class CandleView(ctx: Context) : View(ctx) {
    var candles: List<Candle> = emptyList()
    var lastPrice: Double = 0.0
    var entry: Double = 0.0
    var stop: Double = 0.0
    var take: Double = 0.0

    private val density = resources.displayMetrics.density
    private val bg = Paint()
    private val grid = Paint()
    private val up = Paint()
    private val down = Paint()
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        bg.color = 0xFF14171C.toInt()
        grid.color = 0x22FFFFFF
        grid.strokeWidth = 1f
        up.color = 0xFF2ECC71.toInt()
        up.strokeWidth = 2f
        down.color = 0xFFE74C3C.toInt()
        down.strokeWidth = 2f
        text.color = 0xFF9AA0A6.toInt()
        text.textSize = 11f * density
        lineP.strokeWidth = 2f
        lineP.style = Paint.Style.STROKE
        lineP.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    private fun yOf(v: Double, lo: Double, range: Double, h: Float): Float =
        (4.0 + ((lo + range - v) / range) * (h - 8f)).toFloat()

    private fun hline(c: Canvas, v: Double, lo: Double, range: Double, w: Float, h: Float, plotW: Float, color: Int) {
        if (v <= 0.0 || v < lo || v > lo + range) return
        val yy = yOf(v, lo, range, h)
        lineP.color = color
        c.drawLine(0f, yy, plotW, yy, lineP)
        text.color = color
        text.textAlign = Paint.Align.LEFT
        c.drawText(fmtPrice(v), plotW + 4f * density, yy + 4f * density, text)
        text.color = 0xFF9AA0A6.toInt()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        val d = candles
        val n = d.size
        if (n == 0) {
            text.textAlign = Paint.Align.CENTER
            c.drawText("загрузка свечей...", w / 2f, h / 2f, text)
            return
        }
        val axisW = 64f * density
        val plotW = w - axisW

        var mn = d[0].l
        var mx = d[0].h
        for (k in d) {
            if (k.l < mn) mn = k.l
            if (k.h > mx) mx = k.h
        }
        var span = mx - mn
        if (span < 1e-12) span = 1.0
        val lo = mn - span * 0.06
        val range = span * 1.12

        for (i in 0..4) {
            val v = lo + range * i / 4.0
            val yy = yOf(v, lo, range, h)
            c.drawLine(0f, yy, plotW, yy, grid)
            text.textAlign = Paint.Align.LEFT
            c.drawText(fmtPrice(v), plotW + 4f * density, yy + 4f * density, text)
        }

        val cw = plotW / n
        val half = Math.max(1f, cw * 0.32f)
        for (i in 0 until n) {
            val k = d[i]
            val p = if (k.c >= k.o) up else down
            val x = cw * i + cw / 2f
            c.drawLine(x, yOf(k.h, lo, range, h), x, yOf(k.l, lo, range, h), p)
            val yo = yOf(k.o, lo, range, h)
            val yc = yOf(k.c, lo, range, h)
            val top = Math.min(yo, yc)
            var bot = Math.max(yo, yc)
            if (bot - top < 1.5f) bot = top + 1.5f
            c.drawRect(x - half, top, x + half, bot, p)
        }

        hline(c, entry, lo, range, w, h, plotW, 0xFFF1C40F.toInt())
        hline(c, stop, lo, range, w, h, plotW, 0xFFE74C3C.toInt())
        hline(c, take, lo, range, w, h, plotW, 0xFF2ECC71.toInt())
        val lp = if (lastPrice > 0.0) lastPrice else d[n - 1].c
        hline(c, lp, lo, range, w, h, plotW, 0xFFFFFFFF.toInt())
    }
}
