package com.livetrader

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Живые цены и свечи с публичного API Binance (без ключей). */
object Market {
    @Volatile var selected: String = "BTCUSDT"
    @Volatile var interval: String = "1m"
    @Volatile var lastError: String = ""
    @Volatile var candles: List<Candle> = emptyList()
    @Volatile var candlesKey: String = ""
    val price = ConcurrentHashMap<String, Double>()
    val change = ConcurrentHashMap<String, Double>()

    private val hist = HashMap<String, ArrayList<Double>>()
    private var thread: Thread? = null
    private val bases = listOf("https://data-api.binance.vision", "https://api.binance.com")

    fun history(sym: String): List<Double> = synchronized(hist) {
        val l = hist[sym]
        if (l == null) emptyList<Double>() else ArrayList<Double>(l)
    }

    @Synchronized
    fun start() {
        if (thread?.isAlive == true) return
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun loop() {
        var tick = 0
        while (true) {
            if (Bus.uiVisible || Bus.running) {
                val syms = HashSet<String>()
                syms.add(selected)
                val p = Paper.pos
                if (p != null) syms.add(p.symbol)
                for (s in syms) fetch(s)
                if (Bus.uiVisible && (tick % 2 == 0 || candlesKey != selected + interval)) {
                    fetchCandles(selected, interval)
                }
                Bus.ping()
            }
            tick++
            try {
                Thread.sleep(2000)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun fetchCandles(sym: String, iv: String) {
        for (b in bases) {
            try {
                val arr = JSONArray(Http.get("$b/api/v3/klines?symbol=$sym&interval=$iv&limit=60"))
                val list = ArrayList<Candle>()
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    list.add(
                        Candle(
                            k.getString(1).toDouble(), k.getString(2).toDouble(),
                            k.getString(3).toDouble(), k.getString(4).toDouble()
                        )
                    )
                }
                if (sym == selected && iv == interval) {
                    candles = list
                    candlesKey = sym + iv
                }
                return
            } catch (e: Exception) {
                lastError = e.message ?: e.toString()
            }
        }
    }

    private fun fetch(sym: String) {
        for (b in bases) {
            try {
                val j = JSONObject(Http.get("$b/api/v3/ticker/24hr?symbol=$sym"))
                val p = j.getString("lastPrice").toDouble()
                val c = j.getString("priceChangePercent").toDouble()
                price[sym] = p
                change[sym] = c
                synchronized(hist) {
                    val l = hist.getOrPut(sym) { ArrayList<Double>() }
                    l.add(p)
                    if (l.size > 150) l.removeAt(0)
                }
                lastError = ""
                Paper.onPrice(sym, p)
                return
            } catch (e: Exception) {
                lastError = e.message ?: e.toString()
            }
        }
    }
}
