package com.livetrader

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Арбитраж между биржами: сравнивает лучшие цены покупки и продажи одной монеты
 * на нескольких биржах (публичные данные). Только считает, ничего не торгует.
 */
object XArb {
    private class Quote(val name: String, val bid: Double, val ask: Double)

    @Volatile var enabled: Boolean = false
    @Volatile var feePct: Double = 0.1   // комиссия за одну сторону
    @Volatile private var quotes: List<Quote> = emptyList()
    @Volatile private var note: String = ""
    @Volatile private var scans: Int = 0
    @Volatile private var positive: Int = 0
    @Volatile private var bestNet: Double = -100.0
    @Volatile private var bestText: String = ""
    @Volatile private var shownSymbol: String = ""

    private val names = listOf("Binance", "Bybit", "OKX", "KuCoin", "Gate")
    private var thread: Thread? = null

    @Synchronized
    fun start() {
        if (thread?.isAlive == true) return
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun toggle() {
        enabled = !enabled
        Bus.ping()
    }

    fun resetStats() {
        scans = 0
        positive = 0
        bestNet = -100.0
        bestText = ""
        Bus.ping()
    }

    private fun loop() {
        while (true) {
            if (enabled && Bus.uiVisible) {
                try {
                    scan()
                } catch (e: Exception) {
                    note = e.message ?: e.toString()
                }
                Bus.ping()
            }
            try {
                Thread.sleep(4000)
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    private fun num(s: String): Double {
        val v = s.toDouble()
        if (v <= 0.0) throw RuntimeException("нет цены")
        return v
    }

    private fun fetchOne(i: Int, sym: String, base: String): Quote {
        when (i) {
            0 -> {
                val o = JSONObject(
                    Http.getAny(
                        listOf("https://data-api.binance.vision", "https://api.binance.com"),
                        "/api/v3/ticker/bookTicker?symbol=$sym"
                    )
                )
                return Quote("Binance", num(o.getString("bidPrice")), num(o.getString("askPrice")))
            }
            1 -> {
                val o = JSONObject(Http.get("https://api.bybit.com/v5/market/tickers?category=spot&symbol=$sym"))
                val t = o.getJSONObject("result").getJSONArray("list").getJSONObject(0)
                return Quote("Bybit", num(t.getString("bid1Price")), num(t.getString("ask1Price")))
            }
            2 -> {
                val o = JSONObject(Http.get("https://www.okx.com/api/v5/market/ticker?instId=$base-USDT"))
                val t = o.getJSONArray("data").getJSONObject(0)
                return Quote("OKX", num(t.getString("bidPx")), num(t.getString("askPx")))
            }
            3 -> {
                val o = JSONObject(Http.get("https://api.kucoin.com/api/v1/market/orderbook/level1?symbol=$base-USDT"))
                val t = o.getJSONObject("data")
                return Quote("KuCoin", num(t.getString("bestBid")), num(t.getString("bestAsk")))
            }
            else -> {
                val a = JSONArray(Http.get("https://api.gateio.ws/api/v4/spot/tickers?currency_pair=${base}_USDT"))
                val t = a.getJSONObject(0)
                return Quote("Gate", num(t.getString("highest_bid")), num(t.getString("lowest_ask")))
            }
        }
    }

    private fun scan() {
        val sym = Market.selected
        val base = sym.removeSuffix("USDT")
        val res = arrayOfNulls<Quote>(names.size)
        val threads = ArrayList<Thread>()
        for (i in names.indices) {
            val t = Thread {
                try {
                    res[i] = fetchOne(i, sym, base)
                } catch (e: Exception) {
                    // биржа недоступна или такой пары нет
                }
            }
            t.isDaemon = true
            t.start()
            threads.add(t)
        }
        for (t in threads) t.join(10000)

        val got = ArrayList<Quote>()
        val missing = ArrayList<String>()
        for (i in names.indices) {
            val q = res[i]
            if (q != null) got.add(q) else missing.add(names[i])
        }
        quotes = got
        shownSymbol = sym
        note = if (missing.isEmpty()) "" else "Нет данных: " + missing.joinToString(", ")
        if (got.size < 2) return

        var buy = got[0]
        var sell = got[0]
        for (q in got) {
            if (q.ask < buy.ask) buy = q
            if (q.bid > sell.bid) sell = q
        }
        val gross = (sell.bid / buy.ask - 1.0) * 100.0
        val net = gross - feePct * 2.0
        scans++
        if (net > 0.0) positive++
        if (net > bestNet) {
            bestNet = net
            bestText = sym + ": купить " + buy.name + ", продать " + sell.name
        }
    }

    private fun pct(v: Double): String = String.format(Locale.US, "%+.3f", v) + "%"

    fun report(): String {
        if (!enabled) return "Сканер выключен."
        val q = quotes
        if (q.size < 2) return if (note.isEmpty()) "Собираю цены..." else note
        var buy = q[0]
        var sell = q[0]
        for (x in q) {
            if (x.ask < buy.ask) buy = x
            if (x.bid > sell.bid) sell = x
        }
        val gross = (sell.bid / buy.ask - 1.0) * 100.0
        val net = gross - feePct * 2.0
        val sb = StringBuilder()
        sb.append("Актив: ").append(shownSymbol).append(" (меняется вверху)\n\n")
        for (x in q) {
            sb.append(x.name).append(": купить по ").append(fmtPrice(x.ask))
            sb.append(", продать по ").append(fmtPrice(x.bid)).append("\n")
        }
        sb.append("\nЛучшая связка: купить на ").append(buy.name).append(" по ").append(fmtPrice(buy.ask))
        sb.append(", продать на ").append(sell.name).append(" по ").append(fmtPrice(sell.bid)).append("\n")
        sb.append("До комиссии ").append(pct(gross)).append(", после комиссии ").append(pct(net))
        sb.append(" (комиссия ").append(feePct).append("% с каждой стороны)\n")
        if (note.isNotEmpty()) sb.append(note).append("\n")
        sb.append("\nПроверок: ").append(scans).append(". В плюсе после комиссии: ").append(positive).append(" раз.")
        if (bestText.isNotEmpty()) {
            sb.append("\nЛучший результат за всё время: ").append(pct(bestNet)).append(" (").append(bestText).append(")")
        }
        sb.append("\nВажно: деньги нужно держать на обеих биржах заранее. Перевод между биржами занимает минуты и стоит комиссии, а за это время цены сходятся.")
        return sb.toString()
    }
}
